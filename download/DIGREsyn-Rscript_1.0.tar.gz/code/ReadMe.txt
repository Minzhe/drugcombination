doseRes.R
----------------------
function to read the drug dose response data



KEGGpathInfo.R
----------------------
function to generate the KEGG pathway inforamtion from xml file



plotting.R
----------------------
function to plot for visualization drug pair synergistic scores



profileGeneExp.R
----------------------
function to read the drug treated gene expression date and prepare for the input of DIGRE algorithm



scoring.R
----------------------
function to score the drug synergy based on DIGRE algorithm